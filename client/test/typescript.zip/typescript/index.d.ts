
/// <reference path="typescriptServices.d.ts" />
export = ts;