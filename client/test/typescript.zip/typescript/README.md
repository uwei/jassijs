This is a stub types definition for TypeScript (https://github.com/Microsoft/TypeScript).
TypeScript provides its own type definitions, so you don't need @types/typescript installed!